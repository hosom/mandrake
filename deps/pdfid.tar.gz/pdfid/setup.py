from distutils.core import setup

setup(name='pdfid',
	version='0.1.12',
	description='PDF Scanning Utility',
	author='Didier Stevens',
	py_modules=['pdfid'],
)
